#!flask/bin/python
from flask import Flask, jsonify, abort, request, make_response, url_for
from flask import render_template
from flask_httpauth import HTTPBasicAuth
import os
import json

#Attribution: https://blog.miguelgrinberg.com/post/designing-a-restful-api-with-python-and-flask
#reference: https://github.com/realpython/discover-flask
#Needs: pip install flask-httpauth



app = Flask(__name__)
auth = HTTPBasicAuth()

@app.route('/', methods=['GET','POST'])
@auth.login_required
def login():
    print('in login')
    print(request.values.get('email'), request.values.get('password'))
    templateToReturn = 'login.html'
    if request.method == 'POST':
        print('in post')
        username = request.values.get('email')
        password = request.values.get('password')
        if verify_password(username, password):
            print('password verified')
            # templateToReturn = 'index.html'
    print('Curr user', auth.current_user())
    print('request: ', request.method)
    # if request.method == 'GET' and auth.current_user():
    #     templateToReturn = 'index.html'
    print('password2111')
    # return render_template('password')
    return 'password'

@app.route('/receive_json/<name>', methods=['GET','POST'])
# @auth.login_required
def receive_json(name):
    if request.method == 'POST':
        try:
          BOOKMARK_FILE_PATH = f"/DATA/My_data/web/bookmarks/{name}.json"
          # /DATA/My_data/web/bookmarks/Savan.json
            # Assuming the incoming data is JSON
          data = request.json
            # Open the file in write mode and save the JSON data
          with open(BOOKMARK_FILE_PATH, 'w') as json_file:
                json.dump(data, json_file)

            # print(f"JSON data has been saved to {BOOKMARK_FILE_PATH}")

            # Process the received JSON data
            # Here, we simply echo the received data in the response
          return jsonify({'received_data': data, 'status': 'success'})
        except Exception as e:
          return jsonify({'error': str(e), 'status': 'failed'}), 400
    else:
        return jsonify({'error': 'Method not allowed', 'status': 'failed'}), 405  
  

@auth.verify_password
def verify_password(email, password):
    print('in verify pwd')
    return verifyAuthentication(email, password)

def verifyAuthentication(email, password):
    knownUsers = {'admin1': 'admin', 
                  'admin': 'Savan@22797'}
    authenticated = False
    if email in knownUsers:
        if knownUsers[email] == password:
            authenticated = True
    return authenticated

@app.route('/logout')
def logout():
    return render_template('logout.html')

@auth.error_handler
def unauthorized():
    return '<!DOCTYPE html><html><body><div style="text-align: center;">Unauthorized access</div></body></html>'
    
@app.errorhandler(400)
def bad_request(error):
    return '<!DOCTYPE html><html><body><div style="text-align: center;">Bad request</div></body></html>'

@app.errorhandler(404)
def not_found(error):
    return '<!DOCTYPE html><html><body><div style="text-align: center;">Page not found</div></body></html>'

if __name__ == '__main__':
    # Run the Flask application on the local development server
    app.run(host='0.0.0.0', port=80)

