chrome.bookmarks.onChanged.addListener(function (bookmark){
    chrome.browserAction.setBadgeText({ text: 'Changed' }); // Example: set a badge when a message is received

})

chrome.bookmarks.onCreated.addListener(function (bookmark){
    exportBookmarks();
    chrome.browserAction.setBadgeText({ text: 'Created' }); // Example: set a badge when a message is received

})
 
chrome.runtime.getPlatformInfo(function(info) {
  // Display host OS in the console
  console.log(info.os);
});

chrome.bookmarks.onRemoved.addListener(function (bookmark){
    exportBookmarks();
    chrome.browserAction.setBadgeText({ text: 'Removed' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onChildrenReordered.addListener(function (bookmark){
  exportBookmarks();
  chrome.browserAction.setBadgeText({ text: 'ChildrenReordered' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onImportBegan.addListener(function (bookmark){
  exportBookmarks();
  chrome.browserAction.setBadgeText({ text: 'ImportBegan' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onImportEnded.addListener(function (bookmark){
  exportBookmarks();
  chrome.browserAction.setBadgeText({ text: 'ImportEnded' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onMoved.addListener(function (bookmark){
  exportBookmarks();
  chrome.browserAction.setBadgeText({ text: 'Moved' }); // Example: set a badge when a message is received
})


function exportBookmarks() {
  // const apiUrl = 'https://concinnous-tang-0649.dataplicity.io/receive_json';
  const apiUrl = 'http://127.0.0.1:5000/upload/savan';

    chrome.bookmarks.getTree(function (bookmarkNodes) {        
  const bookmarksData1 = extractBookmarks(bookmarkNodes);
    const bookmarksData = JSON.stringify(bookmarksData1, null, 2);
    // bookmarkDataElement.textContent = bookmarksData;
    sendPostRequest(apiUrl,bookmarksData);
  });
}  
  
  function extractBookmarks(bookmarkNodes) {
    const result = [];
  
    for (const node of bookmarkNodes) {
      const bookmark = {
        title: node.title,
        url: node.url,
      };
  
      if (node.children) {
        bookmark.children = extractBookmarks(node.children);
      }
  
      result.push(bookmark);
    }
  
    return result;
  }


// function sendPostRequest(url, data) {
//     // Define the request options
//     const options = {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json', // Set the content type based on your API requirements
//         // Add any additional headers if needed
//       },
//       body: JSON.stringify(data), // Convert data to JSON format
//     };
  
//     // Send the POST request using the fetch function
//     fetch(url, options)
//       .then(response => {
//         if (!response.ok) {
//           throw new Error(`HTTP error! Status: ${response.status}`);
//         }
//         return response.json(); // Assuming the response is in JSON format
//       })
//       .then(data => {
//         console.log('POST request successful:', data);
//         // Handle the response data as needed
//       })
//       .catch(error => {
//         console.error('Error during POST request:', error);
//         // Handle errors
//       });
//   }
  
  // // Example usage:
  // const apiUrl = 'https://example.com/api'; // Replace with your specific API endpoint
  // const postData = {
  //   key1: 'value1',
  //   key2: 'value2',
  //   // Add any other data you want to send in the POST request
  // };
  

function getPathForPlatform(oss) {
  let path = "";
  if (oss === "linux") {
      // Linux path
      path = "~/.config/google-chrome/Default/Bookmarks";
    } else if (oss === "darwin") {
      // macOS path
      path = "~/Library/Application Support/Google/Chrome/Default/Bookmarks";
    } else if (oss === "win32") {
      // Windows path
      path = "~\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Bookmarks";
    }
  
    return path;
  }  


// function sendPostRequest(url, data) {


//   fetch(url, {
//     method: 'POST',
//     headers: {
//       'Content-Type': 'text/plain' // Set the content type to text/plain
//     },
//     body: data
//   })
//   .then(response => {
//     if (response.ok) {
//       console.log('Text data sent successfully');
//       // Handle success if needed
//     } else {
//       console.log('Failed to send text data. Status code:', response.status);
//       // Handle failure if needed
//     }
//   })
//   .catch(error => {
//     console.error('Error:', error);
//     // Handle error if needed
//   });

// }


 function sendPostRequest(url, data) {
      // Define the request options
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain', // Set the content type based on your API requirements
          // Add any additional headers if needed
        },
        body: data, // Convert data to JSON format
      };
    
      // Send the POST request using the fetch function
      fetch(url, options)
        .then(response => {
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.json(); // Assuming the response is in JSON format
        })
        .then(data => {
          console.log('POST request successful:', data);
          // Handle the response data as needed
        })
        .catch(error => {
          console.error('Error during POST request:', error);
          // Handle errors
        });
    }