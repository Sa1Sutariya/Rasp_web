document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('getBookmarks').addEventListener('click', getBookmarks);
  });
  
  function getBookmarks() {
    chrome.bookmarks.getTree(function (bookmarkTreeNodes) {
      const bookmarkList = document.getElementById('bookmarkList');
      bookmarkList.innerHTML = ''; // Clear previous results
  
      traverseBookmarks(bookmarkTreeNodes[0], bookmarkList);
    });
    chrome.bookmarks.onChanged.addListener(
        handleBookmarkChange
      )
  }
  function handleBookmarkChange(id, changeInfo) {
    console.log(`Bookmark ${id} cha nged:`, changeInfo);
    // You can perform additional actions based on the bookmark change here
  }
//   function handleBookmarkChange(id, changeInfo) {
//     // Send a message to the popup with information about the bookmark change
//     chrome.runtime.sendMessage({
//       type: 'bookmarkChanged',
//       id: id,
//       changeInfo: changeInfo
//     });
//   }
  function traverseBookmarks(node, bookmarkList) {
    if (node.children) {
      for (let child of node.children) {
        traverseBookmarks(child, bookmarkList);
      }
    } else if (node.url) {
      // This is a bookmark leaf node
      const listItem = document.createElement('li');
      listItem.textContent = `${node.title}: ${node.url}`;
      bookmarkList.appendChild(listItem);
    }
  }
  


  document.addEventListener('DOMContentLoaded', function() {
    const createFileBtn = document.getElementById('createFileBtn');
  
    createFileBtn.addEventListener('click', function() {
      createAndSaveFile();
    });
  });

  