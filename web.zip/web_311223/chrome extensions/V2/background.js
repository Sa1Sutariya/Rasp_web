/* global chrome, alert, prompt, confirm */

const PC_NAME_KEY = 'x-pc-name'
const TOKEN_FEATURE_INFORMATION_KEY = 'user-knows-name-feature'

const storage = chrome.storage.sync || chrome.storage.local

const updatedUrl = '';


chrome.browserAction.onClicked.addListener((tab) => {
  // console.log("Hello world!");
  handleOldpcname((_, askToSetToken) => {
    if (askToSetToken) {
      askPCname(() => { })
    }
  })
})

chrome.bookmarks.onChanged.addListener(function (bookmark) {
  exportBookmarks();
  // chrome.browserAction.setBadgeText({ text: 'Changed' }); // Example: set a badge when a message is received

})

chrome.bookmarks.onCreated.addListener(function (bookmark) {
  exportBookmarks();
  // chrome.browserAction.setBadgeText({ text: 'Created' }); // Example: set a badge when a message is received

})

chrome.bookmarks.onRemoved.addListener(function (bookmark) {
  exportBookmarks();
  // chrome.browserAction.setBadgeText({ text: 'Removed' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onChildrenReordered.addListener(function (bookmark) {
  exportBookmarks();
  // chrome.browserAction.setBadgeText({ text: 'ChildrenReordered' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onImportBegan.addListener(function (bookmark) {
  exportBookmarks();
  // chrome.browserAction.setBadgeText({ text: 'ImportBegan' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onImportEnded.addListener(function (bookmark) {
  exportBookmarks();
  // chrome.browserAction.setBadgeText({ text: 'ImportEnded' }); // Example: set a badge when a message is received
})

chrome.bookmarks.onMoved.addListener(function (bookmark) {
  exportBookmarks();
  // chrome.browserAction.setBadgeText({ text: 'Moved' }); // Example: set a badge when a message is received
})

const userNowKnowsAboutPCnameFeature = (cb) => {
  const obj = {}
  obj[TOKEN_FEATURE_INFORMATION_KEY] = true

  storage.set(obj, cb)
}

const askPCname = (cb) => {
  const PCname = prompt('Please enter your PC name')

  if (PCname === null) return

  if (PCname) {
    setpcname(PCname, cb)
  } else {
    alert('You have entered an empty token.')

    cb()
  }
}

function setpcname(key, cb) {
  const obj = {}

  obj[PC_NAME_KEY] = key

  storage.set(obj, function () {
    alert('Your PC Name has been set successfully.')

    cb()
  })
}

function handleOldpcname(cb) {
  storage.get(PC_NAME_KEY, function (storedData) {
    const oldpcname = storedData[PC_NAME_KEY]
    // chrome.browserAction.setBadgeText({ text: oldpcname });


    if (oldpcname) {
      if (confirm('You have already set your PC name. Do you want to remove it?')) {
        storage.remove(PC_NAME_KEY, function () {
          alert('You have successfully removed PC name. Click extension icon again to set a new token.')

          cb(null, false)
        })
      } else {
        cb(null, false)
      }
    } else {
      cb(null, true)
    }
  })
}

function retrieveAndUpdateUrl() {

  return new Promise((resolve, reject) => {

    const apiUrl = 'https://hominoid-kingfisher-9038.dataplicity.io/receive_json/';
    // const apiUrl = 'http://127.0.0.1:5000/receive_json/';

    const PC_NAME_KEY = 'x-pc-name'; // Replace with your actual key used in storage

    chrome.storage.sync.get(PC_NAME_KEY, function (storedData) {
      let oldpcname = storedData[PC_NAME_KEY];

      if (oldpcname) {
        let updatedUrl = apiUrl + oldpcname;
        resolve(updatedUrl); // Resolve the Promise with the retrieved PC name
      } else {
        reject("Error: Unable to retrieve PC name.");
      }

    });
  });
}


function Book_data() {

  return new Promise((resolve, reject) => {
    // const apiUrl = 'http://127.0.0.1:5000/receive_data/';
    chrome.bookmarks.getTree(function (bookmarkNodes) {
      const bookmarksData1 = extractBookmarks(bookmarkNodes);
      const bookmarksData = JSON.stringify(bookmarksData1, null, 2);

      if (bookmarksData) {
        // let updatedUrl = apiUrl + oldpcname;
        resolve(bookmarksData); // Resolve the Promise with the retrieved PC name
        // console.log(bookmarksData);

      } else {
        reject("Error: Unable to retrieve PC name.");
      }

    });
  });
}

function exportBookmarks() {

  Promise.all([retrieveAndUpdateUrl(), Book_data()])
    .then((values) => {
      const [updatedUrl, bookmarksData] = values; // Destructuring values retrieved from promises
      sendPostRequest(updatedUrl, bookmarksData); // Execute the function using retrieved values
    })
    .catch((error) => {
      console.error('Error:', error);
    });

}

function informUserAboutPCnameFeature() {

  storage.get(TOKEN_FEATURE_INFORMATION_KEY, function (storedData) {
    const userKnows = storedData[TOKEN_FEATURE_INFORMATION_KEY]
    // console.log(userKnows);
    if (!userKnows) {
      if (confirm('Do you want to add a PC name?')) {
        askPCname(() => {
          userNowKnowsAboutPCnameFeature(() => { })
        })
      } else {
        userNowKnowsAboutPCnameFeature(() => {
          alert('You can click extension icon to set a PC name.')
        })
      }
    }
  })
}

function extractBookmarks(bookmarkNodes) {
  const result = [];

  for (const node of bookmarkNodes) {
    const bookmark = {
      title: node.title,
      url: node.url,
    };

    if (node.children) {
      bookmark.children = extractBookmarks(node.children);
    }

    result.push(bookmark);
  }

  return result;
}


function sendPostRequest(url, data) {
  // Define the request options
  const req = new XMLHttpRequest();

  req.open("POST", url, true);
  req.setRequestHeader("Content-type", "application/json");

  req.onreadystatechange = function () {
    if (this.readyState === XMLHttpRequest.DONE) {
      if (this.status === 200) {
        console.log("Data transferred successfully!");
        // You can add code here to handle successful transfer
      } else {
        console.error("Error:", this.status);
        // Handle error cases here
      }
    }
  };

  req.send(JSON.stringify(data));

}

informUserAboutPCnameFeature()


