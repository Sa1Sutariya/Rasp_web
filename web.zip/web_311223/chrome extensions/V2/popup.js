const askPCname = (cb) => {
  const PCname = prompt('Please enter your Github token')

  if (PCname === null) return

  if (PCname) {
    setpcname(PCname, cb)
  } else {
    alert('You have entered an empty token.')

    cb()
  }
}